#' @title Sample Data
#'
#' @description A COVID-19 subdata, normalized by the RC method

#' @format Two matrices: normalized count matrix (counts) and cell information (cell.Info)

#' @examples counts <- COVID19n$counts
#' @examples cell.Info <- COVID19n$cell.Info
"COVID19n"

