#' @title Sample Data
#'
#' @description A GSE120575 subdata, normalized by the RC method

#' @format Two matrices: normalized count matrix (counts) and cell information (cell.Info)

#' @examples counts <- GSE120575n$counts
#' @examples cell.Info <- GSE120575n$cell.Info
"GSE120575n"
