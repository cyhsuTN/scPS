#' Power calculation for DEA of one cell type between paired groups
#' @description A function to calculate powers for DEA of one cell type between paired groups.
#' @importFrom nleqslv nleqslv
#' @importFrom stats pt qt

#' @param ns Numbers of cells of interest in two stages per subject.
#' @param m Number of subjects.
#' @param vvmean1 Gene means of candidate genes in the pre-stage.
#' @param FC Fold changes of candidate genes between two stages.
#' @param vvrho Cell-cell correlations of candidate genes within subjects.
#' @param hf A curve showing the relationship between gene means and gene standard deviations.
#' @param FDR False discovery rate.

#' @examples set.seed(12345)
#' @examples vvmean1 <- rgamma(1000, shape=2, scale=0.5)
#' @examples FC <- c(rep(2, 50), rep(1, 950))
#' @examples vvrho <- runif(1000, 0, 0.2)
#' @examples hf <- function(x) sqrt(x)
#' @examples powerCal.BA(ns=c(1,1)*70, m=6, vvmean1, FC, vvrho, hf, FDR=0.05)

#' @return \item{power}{Statistical power}
#' @return \item{alpha}{Type I error for each gene comparison}


#' @export
powerCal.BA <- function(ns, m, vvmean1, FC, vvrho, hf, FDR) {

  vvmean2 <- vvmean1 * FC

  idx <- which(vvmean1!=vvmean2)
  K1 <- length(idx)
  K0 <- length(vvmean1) - K1
  vmean1 <- vvmean1[idx]
  vmean2 <- vvmean2[idx]
  vrho <- vvrho[idx]

  alpha <- alpha.FDR(ePower=0.8, FDR, K0, K1)

  eq1 <- function(bb) {
    alpha1 <- exp(bb)/(1+exp(bb))

    falsePositives <- K0*alpha1
    mp <- multiple.power.BA(ns, m, vmean1, vmean2, vrho,
                            hf=hf, alpha=alpha1)
    falsePositives/(falsePositives + mp[2]) - FDR
    #mp[2]/K1
  }

  #sapply(log(seq(0.001, 0.01, 0.001)/(1-seq(0.001, 0.01, 0.001))), function(bb) eq1(bb)  )
  #alpha1 <- 0.002
  #eq1(log(alpha1/(1-alpha1)))


  if(is.na(eq1(log(alpha/(1-alpha))))) {
    pw <- c(NA, NA)
    alpha <- NA
  } else {
    (root.solve <- nleqslv(x=log(alpha/(1-alpha)), fn=eq1, control=list(ftol=1e-6, maxit=15)))

    #if(root.solve$termcd==3 & root.solve$fvec > 0.005) {
    if(root.solve$fvec > 0.005) {
      #if(root.solve$termcd==3) {
      alpha <- NA
      pw <- NA
    } else {
      alpha <- exp(root.solve$x)/(1+exp(root.solve$x))
      #pw <- as.numeric(multiple.power.BA(ns, m, vmean1, vmean2, vrho,
      #                                   hf, alpha=alpha)/K1)

      pw <- (K0*alpha * (1 - (root.solve$fvec+FDR)))/(root.solve$fvec+FDR)/K1
    }

  }

  c(power=pw, alpha=alpha)

}


multiple.power.BA <- function(ns, m, vmean1, vmean2, vrho,
                              hf = function(x) sqrt(x),
                              alpha=0.05) {

  paras <- cbind(vmean1, vmean2, vrho)
  vr <- apply(paras, 1, function(x) {
    #single.power.BA(ns=ns, m=m, mu1=x[1], mu2=x[2], rho=x[3],
    #                hf=hf, alpha=alpha)
    suppressWarnings(vs <- single.power.BA(ns=ns, m=m, mu1=x[1], mu2=x[2], rho=x[3],
                                           hf=hf, alpha=alpha))
  })

  c(K1=nrow(paras), enRejects=sum(vr))
}


single.power.BA <- function(ns, m, mu1, mu2, rho,
                            hf = function(x) sqrt(x),
                            alpha=0.05) {

  mus <- c(mu1, mu2)
  sigmas <- hf(mus)

  mu.by.sigma <- mus/sigmas

  n1 <- ns[1]
  n2 <- ns[2]

  tp1 <- 1/(1-rho)
  tp2 <- rho/(1-rho+(n1+n2)*rho)

  csum.inv.M1 <- tp1 * (1 - n1*tp2 )
  csum.inv.M2 <- tp1 * (  - n2*tp2 )
  csum.inv.M3 <- tp1 * (  - n1*tp2 )
  csum.inv.M4 <- tp1 * (1 - n2*tp2 )

  v11 <- sum(mu.by.sigma * c(csum.inv.M1, csum.inv.M2))
  v12 <- sum(mu.by.sigma * c(csum.inv.M3, csum.inv.M4))
  v21 <- sum(c(0,mu.by.sigma[2]) * c(csum.inv.M1, csum.inv.M2))
  v22 <- sum(c(0,mu.by.sigma[2]) * c(csum.inv.M3, csum.inv.M4))

  list_sum <- m * rbind(c(sum(ns * c(v11, v12) * mu.by.sigma), sum(ns * c(v11, v12) * c(0,mu.by.sigma[2]))),
                        c(sum(ns * c(v21, v22) * mu.by.sigma), sum(ns * c(v21, v22) * c(0,mu.by.sigma[2]))) )
  SIGMA <- solve(list_sum)

  #inv.M <- 1/(1-rho) * (diag(1,(n1+n2))-matrix((rho/(1-rho+(n1+n2)*rho)),(n1+n2),(n1+n2)))
  #V <- diag(c(rep(sigmas[1], n1), rep(sigmas[2], n2))) %*% ((1-rho)*diag(1,(n1+n2)) + rho*matrix(1,(n1+n2),(n1+n2))) %*%
  #  diag(c(rep(sigmas[1], n1), rep(sigmas[2], n2)))
  #inv.V <- diag(1/c(rep(sigmas[1], n1), rep(sigmas[2], n2))) %*% inv.M %*% diag(1/c(rep(sigmas[1], n1), rep(sigmas[2], n2)))
  #D <- cbind( c(rep(mu1, n1), rep(mu2, n2)),
  #            c(rep(0, n1), rep(mu2, n2)))
  #t(D) %*% inv.V %*% D

  effect.size <- (log(mu2)-log(mu1))/sqrt(SIGMA[2,2])
  #  q.alpha <- qnorm(1-alpha/2)
  #  power1 <- pnorm(q.alpha - effect.size, lower.tail = FALSE) + pnorm(-q.alpha - effect.size)
  q.alpha <- qt(1-alpha/2, df=m-2)
  power1 <- pt(q.alpha - effect.size, df=m-2, lower.tail = FALSE) +
    pt(-q.alpha - effect.size, df=m-2)
  as.numeric(power1)

}


alpha.FDR <- function(ePower, FDR, K0, K1) {
  (ePower * K1)*FDR/(K0*(1-FDR))
}
