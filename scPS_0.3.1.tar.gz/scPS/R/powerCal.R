#' Power calculation for DEA of one cell type between two independent groups
#' @description A function to calculate powers for DEA of one cell type between two independent groups.
#' @importFrom nleqslv nleqslv
#' @importFrom stats pt qt

#' @param n Number of cells of interest per subject.
#' @param ms Numbers of subjects in the control and experimental groups, respectively.
#' @param vvmean1 Gene means of candidate genes in the control group.
#' @param FC Fold changes of candidate genes between the control and the experimental groups.
#' @param vvrho Cell-cell correlations of candidate genes within subjects.
#' @param hf A curve showing the relationship between gene means and gene standard deviations.
#' @param FDR False discovery rate.

#' @examples set.seed(12345)
#' @examples vvmean1 <- rgamma(1000, shape=2, scale=0.5)
#' @examples FC <- c(rep(2, 50), rep(1, 950))
#' @examples vvrho <- runif(1000, 0, 0.2)
#' @examples hf <- function(x) sqrt(x)
#' @examples powerCal(n=200, ms=c(1,1)*10, vvmean1, FC, vvrho, hf, FDR=0.05)

#' @return \item{power}{Statistical power}
#' @return \item{alpha}{Type I error for each gene comparison}


#' @export
powerCal <- function(n, ms, vvmean1, FC, vvrho, hf, FDR) {


  vvmean2 <- vvmean1 * FC

  idx <- which(vvmean1!=vvmean2)
  K1 <- length(idx)
  K0 <- length(vvmean1) - K1
  vmean1 <- vvmean1[idx]
  vmean2 <- vvmean2[idx]
  vrho <- vvrho[idx]

  alpha <- alpha.FDR(ePower=0.8, FDR, K0, K1)

  eq1 <- function(bb) {
    alpha1 <- exp(bb)/(1+exp(bb))

    falsePositives <- K0*alpha1
    mp <- multiple.power2(n, ms, vmean1, vmean2, vrho,
                          hf=hf, alpha=alpha1)
    falsePositives/(falsePositives + mp[2]) - FDR
  }

  if(is.na(eq1(log(alpha/(1-alpha))))) {
    pw <- c(NA, NA)
    alpha <- NA
  } else {
    root.solve <- nleqslv(x=log(alpha/(1-alpha)), fn=eq1, control=list(ftol=1e-6, maxit=15))
    #eq1(root.solve$x) + FDR
    #eq1(log(alpha/(1-alpha)))

    #if(root.solve$termcd==3 & root.solve$fvec > 0.005) {
    if(root.solve$fvec > 0.005) {
      alpha <- NA
      pw <- NA
    } else {
      alpha <- exp(root.solve$x)/(1+exp(root.solve$x))
      #pw <- as.numeric(multiple.power2(n, ms, vmean1, vmean2, vrho,
      #                                 hf, alpha=alpha)/K1)

      pw <- (K0*alpha * (1 - (root.solve$fvec+FDR)))/(root.solve$fvec+FDR)/K1
    }

  }

  c(power=pw, alpha=alpha)

}



multiple.power2 <- function(n, ms, vmean1, vmean2, vrho,
                            hf = function(x) sqrt(x),
                            alpha=0.05) {

  paras <- cbind(vmean1, vmean2, vrho)
  vr <- apply(paras, 1, function(x) {
    #x <- paras[131,]
    suppressWarnings(vs <- single.power3(n=n, ms=ms, mu1=x[1], mu2=x[2], rho=x[3],
                                         hf=hf, alpha=alpha))
  })

  c(K1=nrow(paras), enRejects=sum(vr))
}



single.power3 <- function(n, ms, mu1, mu2, rho, ## faster
                          hf = function(x) sqrt(x),
                          alpha=0.05) {

  mus <- c(mu1, mu2)
  sigmas <- hf(mus)

  csum.inv.M <- 1/(1-rho) * (1 - n*(rho/(1-rho+n*rho)) )

  DVD.list <- lapply(c(0,1), function(x) {

    mu <- mus[x+1]
    sigma <- sigmas[x+1]

    csum.inv.V <- sigma^-2 * csum.inv.M

    v1 <- mu   * csum.inv.V
    v2 <- mu*x * csum.inv.V

    ms[x+1] * n * mu * rbind( c(v1, v1 * x),
                              c(v2, v2 * x))

  })

  list_sum <- Reduce("+", DVD.list)
  SIGMA <- solve(list_sum)


  effect.size <- (log(mu2)-log(mu1))/sqrt(SIGMA[2,2])
  #  q.alpha <- qnorm(1-alpha/2)
  #  power1 <- pnorm(q.alpha - effect.size, lower.tail = FALSE) + pnorm(-q.alpha - effect.size)
  #power1 <- max(pnorm(q.alpha - effect.size, lower.tail = FALSE), pnorm(-q.alpha - effect.size))
  #power1 <- pt(qt(1-alpha/2, df=sum(ms)-2) - abs(effect.size), df=sum(ms)-2, lower.tail = FALSE)
  q.alpha <- qt(1-alpha/2, df=sum(ms)-2)
  power1 <- pt(q.alpha - effect.size, df=sum(ms)-2, lower.tail = FALSE) +
    pt(-q.alpha - effect.size, df=sum(ms)-2)
  as.numeric(power1)

}



alpha.FDR <- function(ePower, FDR, K0, K1) {
  (ePower * K1)*FDR/(K0*(1-FDR))
}

