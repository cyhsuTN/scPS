#' Fit a curve between gene means and gene standard deviations
#' @description A function to fit a curve between gene means and gene standard deviations.
#' @import splines
#' @importFrom stats fitted lm pnorm predict
#' @importFrom graphics lines

#' @param preParas estPreParas Object.
#' @param sp.method Spline methods: "bs" (cubic B-spline) and "ns" (natural cubic spline).
#' Default = "ns".
#' @param probs  Inter quantile that will be used as knots in spline methods.
#' @param cell.name cell name.

#' @examples # counts <- COVID19n$counts
#' @examples # cell.info <- COVID19n$cell.info
#' @examples # cells.interesting <- which(cell.info$cellcluster=="Prolif.T")
#' @examples # counts.small <- counts[,cells.interesting]
#' @examples # cell.info.small <- data.frame(id=cell.info[cells.interesting, "SampleId"],
#' @examples #        x1=ifelse(cell.info[cells.interesting, "condition"]=="Neg", 0, 1) )
#' @examples # aa <- estPreParas(counts=counts.small, cell.info=cell.info.small)
#'
#' @examples # ## Select 2000 candidate genes
#' @examples # idx.selected <- which(aa$nonZeroPs1>0.1 & aa$nonZeroPs2>0.1)
#' @examples # logFC <- log(aa$means2[idx.selected]/aa$means1[idx.selected])
#' @examples # idx.cg <- head(idx.selected[order(abs(logFC), decreasing = T)],2000)
#' @examples # aaP <- aa[idx.cg,]
#' @examples # curve.view <- fitSdmean(preParas=aaP, sp.method = "ns")
#' @examples # hf <- curve.view$hf.sigma


#' @export
fitSdmean <- function(preParas, sp.method="ns", probs=c(0.33, 0.67), cell.name=NULL) {
  #xx <- oout[,2]
  #yy <- sqrt(oout[,4])

  xx <- as.numeric(unlist(preParas[,grep("mean", colnames(preParas))]))
  yy <- sqrt(as.numeric(unlist(preParas[,grep("var", colnames(preParas))])))

  if(sp.method=="bs") {
    #fit.spline <- lm(yy ~ bs(xx, knots = quantile(xx, probs )))
    xx <- log(xx)
    fit.spline <- lm(log(yy) ~ bs(xx, knots = quantile(xx, probs )))
  } else {
    #fit.spline <- lm(yy ~ ns(xx, knots = quantile(xx, probs )))
    xx <- log(xx)
    fit.spline <- lm(log(yy) ~ ns(xx, knots = quantile(xx, probs )))
  }

  #plot(xx, yy, xlab = "Gene mean", ylab = "Standard deviation", main = "SD-Mean curve",
  #     cex.lab=1.5, cex.axis=1.5)
  #lines(xx[order(xx)], fitted(fit.spline)[order(xx)], col="red", lwd=2)

  plot(xx, log(yy), xlab = "log(gene mean)", ylab = "log(standard deviation)",
       main = paste0("SD-Mean curve - ", cell.name),
       cex.lab=1.5, cex.axis=1.5)
  lines(xx[order(xx)], fitted(fit.spline)[order(xx)], col="red", lwd=2)

  #plot(exp(xx), yy, xlab = "Gene mean", ylab = "Standard deviation", main = "SD-Mean curve",
  #     cex.lab=1.5, cex.axis=1.5)
  #lines(exp(xx)[order(xx)], exp(fitted(fit.spline)[order(xx)]), col="red", lwd=2)

  #exp(predict(fit.spline, data.frame(xx=xx[order(xx)[1:2]])))
  #exp(head(fitted(fit.spline)[order(xx)]))

  #hf.sigma(xx[order(xx)[1:2]])
  #hf.sigma(exp(xx[order(xx)[1:3]]))


  #hf.sigma <- function(xx) {
  #  predict(fit.spline, data.frame(xx=xx))
  #}

  hf.sigma <- function(uu) {
    xx <- log(uu)
    exp(predict(fit.spline, data.frame(xx=xx)))
  }

  list(hf.sigma=hf.sigma, fit.spline=fit.spline)

}
